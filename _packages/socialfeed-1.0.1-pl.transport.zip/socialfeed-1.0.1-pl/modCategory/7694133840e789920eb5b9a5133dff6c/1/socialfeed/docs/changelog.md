Changelog for socialFeed

socialFeed 1.0.1
---------------------------------
+ Remove Emoji from instagram content to fix breaking imports


socialFeed 1.0.0
---------------------------------
+ Initial Version
