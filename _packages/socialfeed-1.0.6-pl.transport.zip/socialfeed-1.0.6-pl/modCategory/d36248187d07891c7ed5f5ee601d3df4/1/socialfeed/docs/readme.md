
socialFeed

Author: Jan Dähne <https://www.quadro-system.de>
Copyright 2020

Official Documentation: https://www.quadro-system.de/modx-extras/socialfeed/

Bugs and Feature Requests: https://github.com:jdaehne/modxSocialFeed

Questions: http://forums.modx.com
