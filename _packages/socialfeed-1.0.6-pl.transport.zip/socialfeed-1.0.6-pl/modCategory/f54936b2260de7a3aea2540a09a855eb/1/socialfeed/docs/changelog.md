Changelog for socialFeed

socialFeed 1.0.6
---------------------------------
+ Fix import FeedItems
+ Improve removing emojicons from content


socialFeed 1.0.5
---------------------------------
+ Fix CURL issue with SSL


socialFeed 1.0.4
---------------------------------
+ Fix import array issue


socialFeed 1.0.3
---------------------------------
+ Fix clearing cache with different cacheKey


socialFeed 1.0.2
---------------------------------
+ Import more than 15 items


socialFeed 1.0.1
---------------------------------
+ Remove Emoji from instagram content to fix breaking imports


socialFeed 1.0.0
---------------------------------
+ Initial Version
