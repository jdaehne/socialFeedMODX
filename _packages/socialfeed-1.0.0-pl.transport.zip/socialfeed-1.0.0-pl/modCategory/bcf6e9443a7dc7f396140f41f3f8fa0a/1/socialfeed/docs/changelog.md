Changelog for socialFeed

socialFeed 1.0.0
---------------------------------
+ Initial Version
